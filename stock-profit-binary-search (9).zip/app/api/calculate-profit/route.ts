import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { prices } = await request.json()

    if (!Array.isArray(prices) || prices.length < 2) {
      return NextResponse.json(
        { error: "Invalid input. Please provide an array of at least 2 prices." },
        { status: 400 },
      )
    }

    const result = calculateMaxProfitWithBinarySearch(prices)
    return NextResponse.json(result)
  } catch (error) {
    console.error("Error calculating profit:", error)
    return NextResponse.json({ error: "Failed to calculate profit" }, { status: 500 })
  }
}

// Binary search approach for finding maximum profit
function calculateMaxProfitWithBinarySearch(prices: number[]) {
  if (prices.length < 2) {
    return {
      maxProfit: 0,
      buyDay: -1,
      sellDay: -1,
      executionSteps: [],
    }
  }

  const executionSteps: any[] = []

  // Function to find max profit in a range
  function findMaxProfitInRange(low: number, high: number): { maxProfit: number; buyDay: number; sellDay: number } {
    // Base case: if range has only one or zero elements
    if (low >= high) {
      executionSteps.push({
        low,
        high,
        mid: low,
        currentMaxProfit: 0,
        action: "Base case: Range too small",
      })
      return { maxProfit: 0, buyDay: low, sellDay: low }
    }

    // Base case: if range has only two elements
    if (high - low === 1) {
      const profit = prices[high] - prices[low]
      const maxProfit = profit > 0 ? profit : 0

      executionSteps.push({
        low,
        high,
        mid: low,
        currentMaxProfit: maxProfit,
        action: `Base case: Two elements, profit = ${maxProfit}`,
      })

      return {
        maxProfit,
        buyDay: profit > 0 ? low : high,
        sellDay: profit > 0 ? high : high,
      }
    }

    // Divide the range
    const mid = Math.floor((low + high) / 2)

    executionSteps.push({
      low,
      high,
      mid,
      currentMaxProfit: 0,
      action: `Dividing range at mid=${mid}`,
    })

    // Find max profit in left half
    const leftResult = findMaxProfitInRange(low, mid)

    // Find max profit in right half
    const rightResult = findMaxProfitInRange(mid + 1, high)

    // Find max profit crossing the middle
    let minPriceIndex = low
    let minPrice = prices[low]

    for (let i = low; i <= mid; i++) {
      if (prices[i] < minPrice) {
        minPrice = prices[i]
        minPriceIndex = i
      }
    }

    let maxPriceIndex = mid + 1
    let maxPrice = prices[mid + 1]

    for (let i = mid + 1; i <= high; i++) {
      if (prices[i] > maxPrice) {
        maxPrice = prices[i]
        maxPriceIndex = i
      }
    }

    const crossingProfit = maxPrice - minPrice
    const crossingResult = {
      maxProfit: crossingProfit > 0 ? crossingProfit : 0,
      buyDay: crossingProfit > 0 ? minPriceIndex : maxPriceIndex,
      sellDay: crossingProfit > 0 ? maxPriceIndex : maxPriceIndex,
    }

    const currentMaxProfit = Math.max(leftResult.maxProfit, rightResult.maxProfit, crossingResult.maxProfit)

    // Record this step
    executionSteps.push({
      low,
      high,
      mid,
      leftMaxProfit: leftResult.maxProfit,
      rightMaxProfit: rightResult.maxProfit,
      crossingMaxProfit: crossingResult.maxProfit,
      currentMaxProfit,
      action: `Comparing profits: Left=${leftResult.maxProfit.toFixed(2)}, Right=${rightResult.maxProfit.toFixed(2)}, Crossing=${crossingResult.maxProfit.toFixed(2)}`,
    })

    // Return the maximum of the three results
    if (leftResult.maxProfit >= rightResult.maxProfit && leftResult.maxProfit >= crossingResult.maxProfit) {
      return leftResult
    } else if (rightResult.maxProfit >= leftResult.maxProfit && rightResult.maxProfit >= crossingResult.maxProfit) {
      return rightResult
    } else {
      return crossingResult
    }
  }

  const result = findMaxProfitInRange(0, prices.length - 1)

  return {
    ...result,
    executionSteps,
  }
}

