import StockProfitCalculator from "@/components/stock-profit-calculator"

export default function Home() {
  return (
    <main className="container mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold mb-6 text-center">Stock Profit Maximizer</h1>
      <p className="text-gray-600 mb-8 text-center max-w-2xl mx-auto">
        This application demonstrates how binary search can be used to find the maximum profit possible from buying and
        selling stocks. Enter your own stock prices or generate random data.
      </p>
      <StockProfitCalculator />
    </main>
  )
}

