export function generateRandomPrices(count: number): number[] {
  const prices: number[] = []

  // Generate random prices between 50 and 200
  for (let i = 0; i < count; i++) {
    const price = Math.round((50 + Math.random() * 150) * 100) / 100
    prices.push(price)
  }

  return prices
}

// This is a client-side implementation of the algorithm
// The server-side implementation is in the API route
export function calculateMaxProfit(prices: number[]) {
  if (prices.length < 2) {
    return {
      maxProfit: 0,
      buyDay: -1,
      sellDay: -1,
      executionSteps: [],
    }
  }

  const executionSteps: any[] = []
  let maxProfit = 0
  let buyDay = 0
  let sellDay = 0

  // Find the lowest price
  let minPrice = prices[0]
  let minPriceIndex = 0

  for (let i = 1; i < prices.length; i++) {
    // If we find a new minimum price, update it
    if (prices[i] < minPrice) {
      minPrice = prices[i]
      minPriceIndex = i
    }

    // Calculate profit if we sell at current price
    const currentProfit = prices[i] - minPrice

    // Update max profit if current profit is greater
    if (currentProfit > maxProfit) {
      maxProfit = currentProfit
      buyDay = minPriceIndex
      sellDay = i
    }

    // Record this step
    executionSteps.push({
      day: i,
      currentPrice: prices[i],
      minPrice,
      minPriceIndex,
      currentProfit,
      maxProfit,
      buyDay,
      sellDay,
    })
  }

  return {
    maxProfit,
    buyDay,
    sellDay,
    executionSteps,
  }
}

// Binary search approach for finding maximum profit
// This is more for demonstration purposes as the linear approach is actually more efficient for this problem
export function calculateMaxProfitWithBinarySearch(prices: number[]) {
  if (prices.length < 2) {
    return {
      maxProfit: 0,
      buyDay: -1,
      sellDay: -1,
      executionSteps: [],
    }
  }

  const executionSteps: any[] = []

  // Function to find max profit in a range
  function findMaxProfitInRange(low: number, high: number): { maxProfit: number; buyDay: number; sellDay: number } {
    // Base case: if range has only one or zero elements
    if (low >= high) {
      return { maxProfit: 0, buyDay: low, sellDay: low }
    }

    // Base case: if range has only two elements
    if (high - low === 1) {
      const profit = prices[high] - prices[low]
      return {
        maxProfit: profit > 0 ? profit : 0,
        buyDay: profit > 0 ? low : high,
        sellDay: profit > 0 ? high : high,
      }
    }

    // Divide the range
    const mid = Math.floor((low + high) / 2)

    // Find max profit in left half
    const leftResult = findMaxProfitInRange(low, mid)

    // Find max profit in right half
    const rightResult = findMaxProfitInRange(mid + 1, high)

    // Find max profit crossing the middle
    let minPriceIndex = low
    let minPrice = prices[low]

    for (let i = low; i <= mid; i++) {
      if (prices[i] < minPrice) {
        minPrice = prices[i]
        minPriceIndex = i
      }
    }

    let maxPriceIndex = mid + 1
    let maxPrice = prices[mid + 1]

    for (let i = mid + 1; i <= high; i++) {
      if (prices[i] > maxPrice) {
        maxPrice = prices[i]
        maxPriceIndex = i
      }
    }

    const crossingProfit = maxPrice - minPrice
    const crossingResult = {
      maxProfit: crossingProfit > 0 ? crossingProfit : 0,
      buyDay: crossingProfit > 0 ? minPriceIndex : maxPriceIndex,
      sellDay: crossingProfit > 0 ? maxPriceIndex : maxPriceIndex,
    }

    // Record this step
    executionSteps.push({
      low,
      high,
      mid,
      leftMaxProfit: leftResult.maxProfit,
      rightMaxProfit: rightResult.maxProfit,
      crossingMaxProfit: crossingResult.maxProfit,
      currentMaxProfit: Math.max(leftResult.maxProfit, rightResult.maxProfit, crossingResult.maxProfit),
      action: `Comparing profits: Left=${leftResult.maxProfit}, Right=${rightResult.maxProfit}, Crossing=${crossingResult.maxProfit}`,
    })

    // Return the maximum of the three results
    if (leftResult.maxProfit >= rightResult.maxProfit && leftResult.maxProfit >= crossingResult.maxProfit) {
      return leftResult
    } else if (rightResult.maxProfit >= leftResult.maxProfit && rightResult.maxProfit >= crossingResult.maxProfit) {
      return rightResult
    } else {
      return crossingResult
    }
  }

  const result = findMaxProfitInRange(0, prices.length - 1)

  return {
    ...result,
    executionSteps,
  }
}

