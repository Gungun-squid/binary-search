"use client"

import { useState } from "react"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ReferenceLine, ResponsiveContainer } from "recharts"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Slider } from "@/components/ui/slider"
import { generateRandomPrices } from "@/lib/stock-utils"
import { ArrowRight, RefreshCw } from "lucide-react"

export default function StockProfitCalculator() {
  const [stockPrices, setStockPrices] = useState<number[]>([])
  const [manualInput, setManualInput] = useState("")
  const [result, setResult] = useState<{
    maxProfit: number
    buyDay: number
    sellDay: number
    executionSteps: any[]
  } | null>(null)
  const [dataSize, setDataSize] = useState(10)
  const [isLoading, setIsLoading] = useState(false)
  const [activeTab, setActiveTab] = useState("random")

  const handleGenerateRandom = () => {
    const prices = generateRandomPrices(dataSize)
    setStockPrices(prices)
    setResult(null)
  }

  const handleManualSubmit = () => {
    try {
      const prices = manualInput
        .split(",")
        .map((num) => Number.parseFloat(num.trim()))
        .filter((num) => !isNaN(num))

      if (prices.length < 2) {
        alert("Please enter at least 2 valid numbers separated by commas")
        return
      }

      setStockPrices(prices)
      setResult(null)
    } catch (error) {
      alert("Invalid input. Please enter numbers separated by commas")
    }
  }

  const handleCalculate = async () => {
    if (stockPrices.length < 2) {
      alert("Please generate or enter stock prices first")
      return
    }

    setIsLoading(true)
    try {
      const response = await fetch("/api/calculate-profit", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ prices: stockPrices }),
      })

      if (!response.ok) {
        throw new Error("Failed to calculate profit")
      }

      const data = await response.json()
      setResult(data)
    } catch (error) {
      console.error("Error calculating profit:", error)
      alert("Error calculating profit. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  const chartData = stockPrices.map((price, index) => ({
    day: index + 1,
    price,
  }))

  return (
    <div className="grid gap-8 md:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>Stock Prices</CardTitle>
          <CardDescription>Enter stock prices or generate random data</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="random">Random Data</TabsTrigger>
              <TabsTrigger value="manual">Manual Input</TabsTrigger>
            </TabsList>
            <TabsContent value="random" className="space-y-4">
              <div className="space-y-2 pt-4">
                <div className="flex justify-between">
                  <span className="text-sm">Data Size: {dataSize}</span>
                </div>
                <Slider value={[dataSize]} min={5} max={30} step={1} onValueChange={(value) => setDataSize(value[0])} />
              </div>
              <Button onClick={handleGenerateRandom} className="w-full">
                <RefreshCw className="mr-2 h-4 w-4" />
                Generate Random Prices
              </Button>
            </TabsContent>
            <TabsContent value="manual" className="space-y-4">
              <div className="space-y-2 pt-4">
                <div className="text-sm text-muted-foreground">
                  Enter prices separated by commas (e.g., 10, 7, 5, 8, 11, 9)
                </div>
                <Input
                  value={manualInput}
                  onChange={(e) => setManualInput(e.target.value)}
                  placeholder="10, 7, 5, 8, 11, 9"
                />
              </div>
              <Button onClick={handleManualSubmit} className="w-full">
                Submit Prices
              </Button>
            </TabsContent>
          </Tabs>

          {stockPrices.length > 0 && (
            <div className="mt-6">
              <h3 className="text-sm font-medium mb-2">Stock Prices:</h3>
              <div className="text-sm bg-muted p-2 rounded overflow-x-auto">[{stockPrices.join(", ")}]</div>
              <div className="h-[200px] mt-4">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="day" label={{ value: "Day", position: "insideBottom", offset: -5 }} />
                    <YAxis label={{ value: "Price", angle: -90, position: "insideLeft" }} />
                    <Tooltip />
                    <Line type="monotone" dataKey="price" stroke="#8884d8" activeDot={{ r: 8 }} />
                    {result && (
                      <>
                        <ReferenceLine x={result.buyDay + 1} stroke="green" strokeDasharray="3 3" label="Buy" />
                        <ReferenceLine x={result.sellDay + 1} stroke="red" strokeDasharray="3 3" label="Sell" />
                      </>
                    )}
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}
        </CardContent>
        <CardFooter>
          <Button onClick={handleCalculate} disabled={stockPrices.length < 2 || isLoading} className="w-full">
            {isLoading ? "Calculating..." : "Calculate Maximum Profit"}
            {!isLoading && <ArrowRight className="ml-2 h-4 w-4" />}
          </Button>
        </CardFooter>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Binary Search Algorithm</CardTitle>
          <CardDescription>Visualization and results</CardDescription>
        </CardHeader>
        <CardContent>
          {!result ? (
            <div className="flex flex-col items-center justify-center h-[300px] text-center">
              <p className="text-muted-foreground">
                Generate stock prices and calculate to see the binary search algorithm in action
              </p>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-muted rounded-lg p-4 text-center">
                  <div className="text-sm text-muted-foreground">Maximum Profit</div>
                  <div className="text-3xl font-bold">${result.maxProfit.toFixed(2)}</div>
                </div>
                <div className="bg-muted rounded-lg p-4 text-center">
                  <div className="text-sm text-muted-foreground">Buy/Sell Days</div>
                  <div className="text-xl font-bold">
                    Day {result.buyDay + 1} → Day {result.sellDay + 1}
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-sm font-medium mb-2">Algorithm Execution:</h3>
                <div className="bg-muted p-3 rounded-lg text-sm overflow-y-auto max-h-[300px]">
                  {result.executionSteps.map((step, index) => (
                    <div key={index} className="mb-2 last:mb-0">
                      <div className="font-medium">Step {index + 1}:</div>
                      <div className="pl-4">
                        <div>
                          Range: [{step.low} - {step.high}]
                        </div>
                        <div>Mid: {step.mid}</div>
                        <div>Current Max Profit: ${step.currentMaxProfit.toFixed(2)}</div>
                        {step.action && <div>Action: {step.action}</div>}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

